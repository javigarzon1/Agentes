
# Plataforma de Agentes IA Jurídicos — "AvalBot"

Una app web (Lovable Cloud + IA) donde el usuario crea agentes especializados en documentos jurídicos, los configura con su propia base de conocimiento (PDFs como el manual de avales), rellena un formulario con datos del caso concreto, y obtiene **validación + generación de documento**, en pantalla y descargable. Además se entrega un **script Python** que replica la funcionalidad principal en local.

---

## 1. Funcionalidad principal (app web)

### A. Gestión de agentes
- Pantalla "Mis agentes" con tarjetas de cada agente creado.
- Crear agente: nombre, descripción, tipo de documento (avales internacionales, contratos, NDAs, otros), prompt de sistema editable, subida de PDFs como base de conocimiento.
- Un agente "Avales Internacionales" precargado con el manual adjunto.
- Editar / duplicar / eliminar agente.

### B. Uso del agente (formulario dinámico)
Al abrir un agente, se muestra un formulario con campos relevantes al tipo de documento. Para avales internacionales:
- Posición de CaixaBank (garantía directa / contragarantía emitida / contragarantía recibida / double fronting / banco confirmador / crédito documentario / letter of indemnity)
- Partes (ordenante, beneficiario, banco local, banco contragarante)
- Importe y moneda
- Legislación aplicable e idioma
- Vigencia / cláusula evergreen
- Reservas detectadas
- Texto del aval (pegado o subido como PDF/Word)
- Notas adicionales

### C. Resultado del agente
El agente genera dos cosas:
1. **Informe de validación**: tipo de garantía detectada, reservas aplicables según el manual, recomendaciones, advertencias, nivel de riesgo.
2. **Documento generado**: borrador del aval / contragarantía / carta de exoneración con los datos del formulario.

Salida:
- Vista en pantalla con markdown (informe + documento), botón de copiar.
- Descarga en **PDF** y **DOCX**.
- Historial de validaciones por agente.

---

## 2. Script Python complementario

Un script `aval_agent.py` descargable desde la propia app que:
- Lee un PDF de aval desde línea de comandos.
- Usa la misma lógica de prompts que la web (vía Lovable AI Gateway con la API key del usuario).
- Imprime el informe en consola y guarda PDF + DOCX en local.
- Modo interactivo opcional para rellenar el formulario en CLI.

Se entrega como archivo descargable en la web + instrucciones de uso.

---

## 3. Pantallas

1. **Login** (email + Google) — Lovable Cloud Auth
2. **Mis agentes** — listado, botón "Crear agente", agente precargado de avales
3. **Crear / editar agente** — formulario con prompt + subida de PDFs de conocimiento
4. **Usar agente** — formulario dinámico según tipo + área para texto del documento
5. **Resultado** — informe + documento generado, botones Descargar PDF / DOCX / Copiar
6. **Historial** — validaciones previas por agente
7. **Descargar script Python** — página con instrucciones y botón de descarga

---

## 4. Detalles técnicos

**Stack**: TanStack Start + Tailwind + shadcn (ya configurado), Lovable Cloud (DB + Auth + Storage), Lovable AI Gateway (`google/gemini-3-flash-preview` por defecto, opción `gemini-2.5-pro` para casos complejos).

**Modelo de datos (Lovable Cloud)**:
- `profiles` (id, email, full_name)
- `agents` (id, user_id, name, description, doc_type, system_prompt, form_schema jsonb, created_at)
- `agent_documents` (id, agent_id, file_path, filename, parsed_text) — PDFs de conocimiento parseados
- `validations` (id, agent_id, user_id, input_data jsonb, report_md, generated_doc_md, created_at)
- `user_roles` + tabla aparte (no en profiles) con función `has_role` SECURITY DEFINER
- Bucket Storage privado `agent-knowledge` para los PDFs

**Edge functions**:
- `parse-knowledge`: al subir un PDF, lo parsea y guarda el texto en `agent_documents.parsed_text` (chunked).
- `run-agent`: recibe `agent_id` + datos del formulario, construye prompt con system_prompt + conocimiento parseado + datos del caso, llama al AI Gateway con tool calling para devolver `{ report, document }` estructurado, guarda la validación.
- `generate-pdf` y `generate-docx`: convierten el resultado a archivos descargables (usando librerías compatibles con Worker; pdf-lib y docx-js son edge-safe).

**Seguridad**:
- RLS en todas las tablas (cada usuario ve solo sus agentes y validaciones).
- Validación de inputs con zod tanto en cliente como en edge function.
- API key del Gateway nunca expuesta al cliente.
- Manejo de errores 429 / 402 con toasts claros.

**Script Python**:
- Genera al final del proyecto, descargable desde `/public/aval_agent.py`.
- Dependencias: `requests`, `reportlab`, `python-docx`.
- Lee `LOVABLE_API_KEY` del entorno o de un argumento.
- Reutiliza el mismo system prompt que la edge function (se duplica intencionadamente para que funcione standalone).

---

## 5. Entrega por fases (para no construirlo todo de golpe)

**Fase 1** (esta primera implementación):
- Activar Lovable Cloud
- Auth + estructura de DB + RLS
- Pantallas: agentes, crear agente, usar agente, resultado en pantalla
- Edge function `run-agent` funcionando con el manual de avales precargado
- Descarga PDF del informe

**Fase 2** (siguiente turno):
- Subida de PDFs propios como conocimiento + parsing
- Descarga DOCX
- Historial completo

**Fase 3**:
- Script Python descargable + página de instrucciones
- Refinamiento de prompts con casos del manual

¿Procedo con la Fase 1?
